<?php

return [
    'site_title' => 'Punch Today',

];
