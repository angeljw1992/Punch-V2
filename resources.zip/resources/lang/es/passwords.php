<?php

return [
    'password' => 'Las contraseñas deben tener al menos seis caracteres y coincidir con la confirmación.',
    'reset'    => 'Su contraseña ha sido restablecida!',
    'sent'     => 'Hemos enviado por correo electrónico su enlace de restablecimiento de contraseña!',
    'token'    => 'El código de restauración de contraseña es incorrecto.',
    'user'     => 'No podemos encontrar un usuario con esa dirección de correo electrónico.',
    'updated'  => 'Tu contraseña ha sido cambiada!',

];
