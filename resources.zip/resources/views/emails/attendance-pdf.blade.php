<!DOCTYPE html>
<html>
<head>
    <title>Reporte de Asistencia</title>
</head>
<body>
    <h3>Reporte de Asistencia</h3>
    <p>Adjunto encontrarás el informe de asistencia en formato PDF. Este informe fue enviado por: {{ $userName }}.</p>
</body>
</html>
